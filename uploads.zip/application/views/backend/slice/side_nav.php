
<div class="span2 main-menu-span">
				<div class="well nav-collapse sidebar-nav">
					<ul class="nav nav-tabs nav-stacked main-menu">
						<li class="nav-header hidden-tablet">Dashboard</li>
						<li><a class="ajax-link" href="<?php echo site_url('dashboard');?>"><i class="icon-home"></i><span class="hidden-tablet"> Home</span></a></li>
						<li><a class="ajax-link" href="<?php echo site_url('admin/settings');?>"><i class="icon-wrench"></i><span class="hidden-tablet"> Settings</span></a></li>
						
						<li class="nav-header hidden-tablet">Products</li>
						<li><a class="ajax-link" href="<?php echo site_url('admin/product/add');?>"><i class="icon-leaf"></i><span class="hidden-tablet"> Add New</span></a></li>
						<li><a class="ajax-link" href="<?php echo site_url('admin/products');?>"><i class="icon-random"></i><span class="hidden-tablet"> Update</span></a></li>
						
						 <li class="nav-header hidden-tablet">Our Work</li>
						<!--<li><a class="ajax-link" href="<?php echo site_url('admin/ourworks/category/add');?>"><i class="icon-leaf"></i><span class="hidden-tablet"> Add New Category</span></a></li>
						<li><a class="ajax-link" href="<?php echo site_url('admin/ourworks/categories');?>"><i class="icon-random"></i><span class="hidden-tablet"> Update Category</span></a></li>-->
						<li><a class="ajax-link" href="<?php echo site_url('admin/ourworks/add');?>"><i class="icon-leaf"></i><span class="hidden-tablet"> Add New <!--Work--></span></a></li>
						<li><a class="ajax-link" href="<?php echo site_url('admin/ourworks');?>"><i class="icon-random"></i><span class="hidden-tablet"> Update <!--Work--></span></a></li>
						
						<li class="nav-header hidden-tablet">Slider</li>
						<li><a class="ajax-link" href="<?php echo site_url('admin/slider/add');?>"><i class=" icon-picture"></i><span class="hidden-tablet"> Add New</span></a></li>
						<li><a class="ajax-link" href="<?php echo site_url('admin/slider');?>"><i class="icon-random"></i><span class="hidden-tablet"> Update</span></a></li>
		
						<li class="nav-header hidden-tablet">Videos</li>
						<li><a class="ajax-link" href="<?php echo site_url('admin/video/add');?>"><i class="icon-film"></i><span class="hidden-tablet"> Add New</span></a></li>
						<li><a class="ajax-link" href="<?php echo site_url('admin/videos');?>"><i class="icon-random"></i><span class="hidden-tablet"> Update</span></a></li>
						
						<li class="nav-header hidden-tablet">Testimonials</li>
						<li><a class="ajax-link" href="<?php echo site_url('admin/testimonial/add');?>"><i class="icon-comment"></i><span class="hidden-tablet"> Add New</span></a></li>
						<li><a class="ajax-link" href="<?php echo site_url('admin/testimonials');?>"><i class="icon-random"></i><span class="hidden-tablet"> Update</span></a></li>
						
						<li class="nav-header hidden-tablet">Spot Lights</li>
						<li><a class="ajax-link" href="<?php echo site_url('admin/spotlight/add');?>"><i class="icon-comment"></i><span class="hidden-tablet"> Add New</span></a></li>
						<li><a class="ajax-link" href="<?php echo site_url('admin/spotlights');?>"><i class="icon-random"></i><span class="hidden-tablet"> Update</span></a></li>
						
						<li class="nav-header hidden-tablet">Client of Month</li>
						<li><a class="ajax-link" href="<?php echo site_url('admin/spotlight/add');?>"><i class="icon-comment"></i><span class="hidden-tablet"> Add New</span></a></li>
						<li><a class="ajax-link" href="<?php echo site_url('admin/spotlights');?>"><i class="icon-random"></i><span class="hidden-tablet"> Update</span></a></li>
					
					</ul>

				</div><!--/.well -->
				
				
			</div><!--/span-->