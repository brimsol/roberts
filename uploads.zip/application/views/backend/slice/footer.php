<footer>
			<p class="pull-left">&copy; Roberts Awnings  2013</p>
			
		</footer>
</div><!--/.fluid-container-->

	<!-- external javascript
	================================================== -->
	<!-- Placed at the end of the document so the pages load faster -->

	<!-- jQuery -->
	<script src="<?php echo base_url();?>assets/backend/js/jquery-1.8.3.min.js"></script>
	<script src="<?php echo base_url();?>assets/backend/js/bootstrap.js"></script>

	