<div id="mob_nav">
<div id="mob_nav_toggle">
<div id="mob_nav_toggle_link">
  <label><a  id="mob_nav_menu"><img src="<?php echo base_url();?>assets/images/mb-menu.png"  alt="menu"></a></label>
  <label style="float:left;"><a  id="mob_nav_home"><img src="<?php echo base_url();?>assets/images/mb-home.png" alt="home"></a></label>
 </div>
<div id="mob_nav_inner">



<label class="mob_nav_inner_li" id="mobbmenu_a"><a href="<?php echo site_url();?>">Home</a></label>
<label class="mob_nav_inner_li" id="mobbmenu_c"><a href="<?php echo site_url('products');?>">Products</a></label>
<label class="mob_nav_inner_li" id="mobbmenu_b"><a href="<?php echo site_url('about');?>">About Us</a></label>
<label class="mob_nav_inner_li" id="mobbmenu_e"><a href="<?php echo site_url('contact');?>">Contact Us</a></label>




<label class="white"><input type="text" class="mob_search" value="Search" onblur="if (this.value=='') this.value='Search'; " onfocus="if (this.value=='Search') this.value='';" name=""></label>
<label class="mob_nav_right"><a href="#" class="mob_go">Go</a></label>
<div class="clear"></div>
</div>
</div>
</div>