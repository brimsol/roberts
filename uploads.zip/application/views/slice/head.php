<link href="<?php echo base_url('assets');?>/css/style.css" rel="stylesheet" type="text/css">
<!--media Query css-->
<link href="<?php echo base_url('assets');?>/css/media.css" rel="stylesheet" type="text/css">
<!--flexslider css-->
<link rel="stylesheet" href="<?php echo base_url('assets');?>/css/slider.css" type="text/css" media="screen" />
<link rel="stylesheet" href="<?php echo base_url('assets');?>/css/jquery.bxslider.css" type="text/css" media="screen" />

<!--[if IE 7 ]> <html lang="en" class="ie7">    <![endif]-->
<!--[if IE 8 ]> <html lang="en" class="ie8">    <![endif]-->
<!--[if lt IE 9]> <html lang="en" class="ie9">    <![endif]-->
<!--[if lt IE 9]>
	<script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>


<!-- commen juery -->
<script src="<?php echo base_url('assets');?>/js/jquery-1.8.3.min.js"></script>
<!-- mobile juery -->
<script src="<?php echo base_url('assets');?>/js/mobile.js"></script>
<script src="<?php echo base_url('assets');?>/js/jquery.easing.1.3.js"></script>
<script src="<?php echo base_url('assets');?>/js/commen.js"></script>

<script src="<?php echo base_url('assets');?>/js/jquery.bxslider.js"></script>
<script src="<?php echo base_url('assets');?>/js/jquery.bxslider.min.js"></script>
<!-- Add jQuery library -->

<!-- Add fancyBox -->
<link rel="stylesheet" href="<?php echo base_url('assets');?>/fancybox/source/jquery.fancybox.css" type="text/css" media="screen" />
<script type="text/javascript" src="<?php echo base_url('assets');?>/fancybox/source/jquery.fancybox.pack.js"></script>