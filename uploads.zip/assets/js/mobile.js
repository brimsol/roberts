// JavaScript Document

$(document).ready (function(){
	
$("#mob_nav_inner").hide();
	$("#mob_nav_menu").click(function(){
	$("#mob_nav_inner").slideToggle();
	});
	
	});