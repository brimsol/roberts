<div id="footer">
	<div id="footer_inner">

		<div id="footer_inner_menu">
			<h2>Menu</h2>
			<ul>
				<li>
					<a href="<?php echo site_url(); ?>">Home </a>
				</li>
				<li>
					<a href="<?php echo site_url('products'); ?>">Products</a>
				</li>
				<li>
					<a href="<?php echo site_url('ourworks'); ?>">Our Works</a>
				</li>
				<li>
					<a href="<?php echo site_url('about'); ?>">About US</a>
				</li>
				<li>
					<a href="<?php echo site_url('admin'); ?>">Admin</a>
				</li>
			</ul>
		</div>

		<div class="rightborder"></div>

		<div id="footer_inner_contact">
			<h2>Contacts</h2>
			<div class="footer_inner_contact_left">
				<p>
					Roberts Awning & Sign
				</p>
				<p>
					1791 Midway Avenue,
				</p>
				<p>
					Petersburg, VA 23803
				</p>
				<label class="contact_mail"><h3><span class="calll"></span>Call 804-733-6012</h3></label>
				<label class="contact_mail"><h4><span class="mail"></span>info@robertsawningandsign.com</h4></label>
				<div class="clear"></div>
			</div>

		</div>
		<!-- map start -->
		<div class="map">
			<!--
			<iframe width="100%" height="100%" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=Roberts+Awning+%26+Sign++1791+Midway+Avenue,++Petersburg,+VA+23803&amp;aq=&amp;sll=42.059787,-62.410134&amp;sspn=68.402878,173.144531&amp;t=m&amp;ie=UTF8&amp;hq=Roberts+Awning+%26+Sign++1791+Midway+Avenue,++Petersburg,+VA+23803&amp;hnear=&amp;radius=15000&amp;ll=37.220622,-77.435112&amp;spn=0.071946,0.071946&amp;output=embed"></iframe>
			-->

		</div>
		<!-- map close -->
		<div class="rightborder"></div>

		<div id="footer_inner_socialmedia">
			<h2>Follow Us</h2>
			<div id="mobile_socialmedia">
				<label class="abc" ><a href="#" ><img src="<?php echo base_url(); ?>assets/images/facebook_32.png" alt="facebook"></a></label>
				<label class="abc" ><a href="#" ><img src="<?php echo base_url(); ?>assets/images/twitter_32.png"  alt="twitter"></a></label>
				<label class="abc" ><a href="#" ><img src="<?php echo base_url(); ?>assets/images/lastfm_32.png" alt="blog"></a></label>
				<label class="abc" ><a href="#" ><img src="<?php echo base_url(); ?>assets/images/tumblr_32.png"  alt="penterest"></a></label>
				<label class="abc" ><a href="#" ><img src="<?php echo base_url(); ?>assets/images/linkedin_32.png"  alt="penterest"></a></label>
			</div>
			<script type="text/javascript">
								$(document).ready(function() {
				$(".fancybox").fancybox();
				$(".spotlight_slide_li").dotdotdot({

				ellipsis : '...',
				wrap : 'word',
				after : '<span class="qtn_b"></span><a><span class="more"></span></a><span class="spotlight_slide_li_shadow"><img src="<?php echo base_url(); ?>assets/images/shadowslide.png" alt="shadow"></span>',
					watch : false,
					height : null,
					tolerance : 0,
					lastCharacter : {

					/* Remove these characters from the end of the truncated text. */
					remove : [' ', ',', ';', '.', '!', '?'],

					/* Don't add an ellipsis if this array contains
					the last character of the truncated text. */
					noEllipsis : []
					}
					});

					$(".more").click(function() {
					 $('.spotlight_slide_li').css('height' , '100%');	
					$(".spotlight_slide_li").trigger("destroy");
					
					});
             $(".client_month_li").dotdotdot({

				ellipsis : '...',
				wrap : 'word',
				after : '<span class="qtn_b"></span></p><span class="more"><a href=""></a></span><span class="client_month_li_shadow"><img src="<?php echo base_url();?>assets/images/shadowslide.png" alt="shadow"></span>',
					watch : false,
					height : null,
					tolerance : 0,
					lastCharacter : {

					/* Remove these characters from the end of the truncated text. */
					remove : [' ', ',', ';', '.', '!', '?'],

					/* Don't add an ellipsis if this array contains
					the last character of the truncated text. */
					noEllipsis : []
					}
					});

					$(".more").click(function() {
					 $('.client_month_li').css('height' , '100%');	
					$(".client_month_li").trigger("destroy");
					
					});
					});
			</script>
		</div>

		<div class="clear"></div>	</div>

	<div class="copyright">
		© Roberts Awning & Sign; All Rights Reserved
	</div>

</div>