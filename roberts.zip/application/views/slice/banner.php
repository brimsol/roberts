<div class="banner_image">
  <img src="<?php echo base_url('assets');?>/images/about_bannerimage.png"  alt="banner"> 
  </div>